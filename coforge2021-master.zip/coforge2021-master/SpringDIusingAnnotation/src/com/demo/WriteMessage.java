package com.demo;

public class WriteMessage {
	
	
	public WriteMessage() {
		
		System.out.println(" constructor  from writeMessage class");
	}
	
	
	public void WriteMessage() {
		System.out.println(" from write message class");
		
	}

}
