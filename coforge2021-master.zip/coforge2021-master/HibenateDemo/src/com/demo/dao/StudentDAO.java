package com.demo.dao;

import com.demo.pojo.Student;

public interface StudentDAO {
	
	
	// insert records for student
	public Student createStudent(Student student);   //done
}
