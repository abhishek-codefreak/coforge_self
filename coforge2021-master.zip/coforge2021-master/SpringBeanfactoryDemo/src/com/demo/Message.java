package com.demo;

public class Message {
	
	//this is my property
	private String messge;

	public String getMessge() {
		return messge;
	}

	public void setMessge(String messge) {
		this.messge = messge;
	}

}
